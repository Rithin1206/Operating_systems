/*
 File: scheduler.C
 
 Author:
 Date  :
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "scheduler.H"
#include "thread.H"
#include "console.H"
#include "utils.H"
#include "assert.H"
#include "simple_keyboard.H"


/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   S c h e d u l e r  */
/*--------------------------------------------------------------------------*/

Scheduler::Scheduler() {
  Console::puts("Constructed Scheduler.\n");
  this->bDisk=NULL;
  diskBusy= false;
}
void Scheduler::add_disk(BlockingDisk * _bDisk) {
  this->bDisk = _bDisk;
}
void Scheduler::yield() {

  Thread* nextThreadToRun= NULL;
  if(!diskBusy && bDisk && bDisk->is_ready() && bDisk->bq_size!=0){
    nextThreadToRun= bDisk->bq->getfront();
    bDisk->bq_size--;
  }
  else{
    diskBusy=false;
    nextThreadToRun = ready_queue.getfront();
    ready_queue.pop();
  }
  Thread :: dispatch_to(nextThreadToRun);

}

void Scheduler::resume(Thread * _thread) {
  bool flag= false;
  if( Machine::interrupts_enabled()){
    flag= true;
     Machine::disable_interrupts();
  }
  ready_queue.insert(_thread);
  if(!Machine::interrupts_enabled() && flag){
      Machine::enable_interrupts();
    }
}

void Scheduler::add(Thread * _thread) {
  bool flag= false;
  if( Machine::interrupts_enabled()){
    flag= true;
     Machine::disable_interrupts();
  }
  ready_queue.insert(_thread);
  if(!Machine::interrupts_enabled() && flag){
      Machine::enable_interrupts();
    }
}

void Scheduler::terminate(Thread * _thread) {
  bool flag= false;
  if( Machine::interrupts_enabled()){
    flag= true;
     Machine::disable_interrupts();
  }
  ready_queue.deleteThisNode(_thread);
  if(!Machine::interrupts_enabled() && flag){
      Machine::enable_interrupts();
    }
}
