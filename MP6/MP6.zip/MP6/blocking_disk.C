/*
     File        : blocking_disk.c

     Author      : 
     Modified    : 

     Description : 

*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "utils.H"
#include "console.H"
#include "blocking_disk.H"

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/

BlockingDisk::BlockingDisk(DISK_ID _disk_id, unsigned int _size,  Scheduler *_scheduler) 
  : SimpleDisk(_disk_id, _size) {
    this->bq= new queue();
    this->scheduler= _scheduler;
    this->scheduler->add_disk(this);
    this->bq_size=0;
}

/*--------------------------------------------------------------------------*/
/* SIMPLE_DISK FUNCTIONS */
/*--------------------------------------------------------------------------*/
void BlockingDisk::wait_until_ready(){
  this->scheduler->diskBusy= true;
  if(this->scheduler->diskBusy || !is_ready())
	{
    Thread *t = Thread::CurrentThread();
    bq->insert(t);
    bq_size++;
    this->scheduler->yield();		
	}
  this->scheduler->diskBusy=false;
}
void BlockingDisk::read(unsigned long _block_no, unsigned char * _buf) {
  // -- REPLACE THIS!!!
  Console::puts("Blocking read \n");
  SimpleDisk::read(_block_no, _buf);

}

bool BlockingDisk::is_ready()
{
  return SimpleDisk::is_ready();		
}	

void BlockingDisk::write(unsigned long _block_no, unsigned char * _buf) {
  // -- REPLACE THIS!!!
  Console::puts("Blocking write \n");
  SimpleDisk::write(_block_no, _buf);
}
