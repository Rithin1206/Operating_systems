/*
     File        : file.C

     Author      : Riccardo Bettati
     Modified    : 2021/11/28

     Description : Implementation of simple File class, with support for
                   sequential read/write operations.
*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file.H"
#include "file_system.H"

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR/DESTRUCTOR */
/*--------------------------------------------------------------------------*/

File::File(FileSystem *_fs, int _id) {
    Console::puts("\n Opening file.");Console::puti(_id); Console::puts("\n");
    id=_id;
    fs=_fs;
    size=0;
    curr_pos=0;
    // assert(false);
}

File::~File() {
    Console::puts("\nClosing file: ");Console::puti(this->id); Console::puts("\n");
    /* Make sure that you write any cached data to disk. */
    /* Also make sure that the inode in the inode list is updated. */
}

/*--------------------------------------------------------------------------*/
/* FILE FUNCTIONS */
/*--------------------------------------------------------------------------*/

int File::Read(unsigned int _n, char *_buf) {
    Console::puts("\nreading from file with id: ");Console::puti(this->id); Console::puts("\n");
    if(fs==NULL){
        Console::puts(" FileSystem not intialized, can not read \n");
        return 0;
    } 
    Inode* inode= fs->LookupFile(id);
    int block= inode->block_num;

    int read = 0;
    int bytes_to_read = _n;

    Console::puts("Reading block "); Console::puti(inode->block_num);Console::puts("\n");
    fs->disk->read(block, (unsigned char *)block_cache);
    //  Console::puts("Curr pos: "); Console::puti(curr_pos);Console::puts("\n");
    while((bytes_to_read > 0)){
        _buf[read]= block_cache[curr_pos];
        bytes_to_read--;
        read++; 
        curr_pos++;
        // Console::puts("Next pos: "); Console::puti(curr_pos);
        // Console::puts(" read: "); Console::puti(read);
        // Console::puts("\n");
        if(curr_pos>= 512){
             Console::puts("we are fucked \n");
            return read;
        }
    }
    return read;
    // assert(false);
}

int File::Write(unsigned int _n, const char *_buf) {
    Console::puts("\n writing to file ");Console::puti(this->id); Console::puts("\n");
    if(fs==NULL){
        Console::puts("FileSystem not intialized, can not write \n");
        return 0;
    }
    Inode* inode= fs->LookupFile(id);
    int block= inode->block_num;

    int write = 0;
    int bytes_to_write = _n;

    Console::puts("Reading block into buff block num: "); Console::puti(inode->block_num);Console::puts("\n");
    fs->disk->read(block, (unsigned char *)block_cache);

     while(bytes_to_write > 0){
       block_cache[curr_pos]= _buf[write];
       write++;
       curr_pos++;
       bytes_to_write--;
       if(EoF()){
            size++;
       }
       if(size> 512){
            curr_pos--;
            fs->disk->write(block, block_cache);
            return write;
       } 
    }
    curr_pos--;
    fs->disk->write(block, block_cache);
    return write;
    // assert(false);
}

void File::Reset() {
    Console::puts("\n resetting file\n");
    curr_pos=0;
    // assert(false);
}

bool File::EoF() {
    //Console::puts("checking for EoF\n");
    if(curr_pos>=size) return true;
    return false;
    //assert(false);
}
