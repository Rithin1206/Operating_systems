/*
     File        : file_system.C

     Author      : Riccardo Bettati
     Modified    : 2021/11/28

     Description : Implementation of simple File System class.
                   Has support for numerical file identifiers.
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/
    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file_system.H"

/*--------------------------------------------------------------------------*/
/* CLASS Inode */
/*--------------------------------------------------------------------------*/

/* You may need to add a few functions, for example to help read and store 
   inodes from and to disk. */

/*--------------------------------------------------------------------------*/
/* CLASS FileSystem */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/

FileSystem::FileSystem() {
    Console::puts("\n In file system constructor.\n");
    // assert(false);
    FileSystem::disk            = NULL;
    FileSystem::size            = 0;
    FileSystem::total_blocks    = 0;
    FileSystem::num_inodes      = 0;
    FileSystem::inodes          = NULL;
    FileSystem::free_blocks     = NULL;
}

FileSystem::~FileSystem() {
    Console::puts("\n unmounting file system\n");
    /* Make sure that the inode list and the free list are saved. */
    assert(false);
}


/*--------------------------------------------------------------------------*/
/* FILE SYSTEM FUNCTIONS */
/*--------------------------------------------------------------------------*/


bool FileSystem::Mount(SimpleDisk * _disk) {
    Console::puts("\nmounting file system from disk\n");
     if (disk == NULL) {
        disk = _disk;

        //TODO- Update DS
        char buf[512];

        //load inode list
        memset(buf, 0, 512);
        disk->read(0, (unsigned char *)buf);
        inodes = (Inode*) buf;

        //load freeblocks
        memset(buf, 0, 512);
        disk->read(1, (unsigned char *)buf);
        free_blocks= (unsigned char *) buf;

        return true;
    }
    return true;
    /* Here you read the inode list and the free list into memory */
    
    // assert(false);
}

bool FileSystem::Format(SimpleDisk * _disk, unsigned int _size) { // static!
    // Update the disk
    Console::puts("\n formatting disk\n");
    /* Here you populate the disk with an initialized (probably empty) inode list
       and a free list. Make sure that blocks used for the inodes and for the free list
       are marked as used, otherwise they may get overwritten. */
    FileSystem::disk            = _disk;
    FileSystem::size            = _size;
    FileSystem::total_blocks    = (FileSystem::size / SimpleDisk::BLOCK_SIZE) + 1;
    FileSystem::num_inodes      = total_blocks-2;

    Inode inode_list[MAX_INODES]; //inode list
    unsigned char free_block_list[512];// freeblock list

    //Freelist all 1->free except for the first 2;
    for(int i=2; i<512; i++){
        free_block_list[i]=1;
    }
    free_block_list[0]=0;
    free_block_list[1]=0;
    //InodeList all -1;
    for(int i=0; i<MAX_INODES; i++){
        inode_list[i].id= 0;
        inode_list[i].block_num=-1;
        inode_list[i].fs= this;
        inode_list[i].num_blocks=0;
        inode_list[i].blockList= NULL;
        
        // Console::puts(" setting ideal id= "); Console::puti(inode_list[i].id);   Console::puts("\n");
    }

    disk->write(0, (unsigned char*)inode_list);
    disk->write(1, (unsigned char*)free_block_list);

    char buf[512];
    memset(buf, 0, 512);

    disk->read(0, (unsigned char *)buf);
    inodes = (Inode*) buf;
    // for(int i=0; i<MAX_INODES; i++){
    //     Console::puts("for i= "); Console::puti(i);  
    //     Console::puts(" ideal id= "); Console::puti(inode_list[i].id);
    //     Console::puts(" real id= ");Console::puti(inodes[i].id);Console::puts("\n");
    // }

    for (int j = 2; j < total_blocks; j++) {
        disk->write(j, (unsigned char *)buf);
    }
    return true;
    // assert(false);
}

Inode * FileSystem::LookupFile(int _file_id) {
    Console::puts("looking up file with id = "); Console::puti(_file_id); Console::puts("\n");
    /* Here you go through the inode list to find the file. */
    // get the list from disk
    char buf[512];
    memset(buf, 0, 512);
    disk->read(0, (unsigned char *)buf);
    inodes = (Inode*) buf;

    for(int i=0; i<MAX_INODES; i++){
        // Console::puts("for i= "); Console::puti(i);
        // Console::puts(" id= ");Console::puti(inodes[i].id);Console::puts("\n");
        if(inodes[i].id==_file_id){
            return &inodes[i];
        }
    }
    return NULL;
    // assert(false);
}

bool FileSystem::CreateFile(int _file_id) {
    Console::puts(" \n In create file "); Console::puts("\n");
    Console::puts("creating file with id:"); Console::puti(_file_id); Console::puts("\n");
    /* Here you check if the file exists already. If so, throw an error.
       Then get yourself a free inode and initialize all the data needed for the
       new file. After this function there will be a new file on disk. */
    assert (LookupFile(_file_id) == NULL);

    //load inodes
    char buf[512];
    memset(buf, 0, 512);
    disk->read(0, (unsigned char *)buf);
    inodes = (Inode*) buf;
    // Console::puts(" create file check ");Console::puts("\n");
    // for(int i=0; i<MAX_INODES; i++){
    //     Console::puts("for i= "); Console::puti(i);  
    //     Console::puts(" real id= ");Console::puti(inodes[i].id);Console::puts("\n");
    // }

    //load free_blocks
    char buf2[512];
    memset(buf2, 0, 512);
    disk->read(1, (unsigned char *)buf2);
    free_blocks= (unsigned char *) buf2;
    // Console::puts("num_inodes= "); Console::puti(num_inodes); Console::puts("\n");
    for(int i=0; i<MAX_INODES; i++){
        Console::puts("for i= "); Console::puti(i);
        Console::puts(" id= ");Console::puti(inodes[i].id);Console::puts("\n");
        if(inodes[i].id==0){//empty 
            inodes[i].id= _file_id;
            inodes[i].block_num= GetFreeBlock();
            Console::puts("get block "); Console::puti(inodes[i].block_num);Console::puts(" \n ");

            // update corresponding block as taken in freelist 1->free 0->taken
            free_blocks[inodes[i].block_num]=0;

            disk->write(0, (unsigned char*)inodes);
            char buf3[512];
            memset(buf3, 0, 512);
            disk->read(0, (unsigned char *)buf3);
            inodes = (Inode*) buf3;
            // Console::puts(" \n update check ");Console::puts("\n");
            // for(int i=0; i<MAX_INODES; i++){
            //     Console::puts("for i= "); Console::puti(i);  
            //     Console::puts(" real id= ");Console::puti(inodes[i].id);Console::puts("\n");
            // }
            disk->write(1, (unsigned char*)free_blocks);
            memset(buf, 0, 512);
            disk->write(inodes[i].block_num, (unsigned char*)buf);
            return true;
        }
    }
    return false;
   // assert(false);
}

bool FileSystem::DeleteFile(int _file_id) {
    Console::puts("\n deleting file with id:"); Console::puti(_file_id); Console::puts("\n");
    /* First, check if the file exists. If not, throw an error. 
       Then free all blocks that belong to the file and delete/invalidate 
       (depending on your implementation of the inode list) the inode. */
    assert (LookupFile(_file_id) != NULL);

    //load inodes
    char buf[512];
    memset(buf, 0, 512);
    disk->read(0, (unsigned char *)buf);
    inodes = (Inode*) buf;

    //load free_blocks
    char buf2[512];
    memset(buf2, 0, 512);
    disk->read(1, (unsigned char *)buf2);
    free_blocks= (unsigned char *) buf2;

    for(int i=0; i<num_inodes; i++){
        if(inodes[i].id==_file_id){ //found the node to delete
            //deallocate the inode
            inodes[i].id= 0;
            int b= inodes[i].block_num;
            inodes[i].block_num= 0;

            // free the block in freelist
            free_blocks[b]= 1;
            disk->write(0, (unsigned char*)inodes);
            disk->write(1, (unsigned char*)free_blocks);
            return true;
        }
    }
    Console::puts("Something went wrong \n");
    return false;
}

int FileSystem::GetFreeBlock(){
    char buf[512];
    memset(buf, 0, 512);
    disk->read(1, (unsigned char *)buf);
    free_blocks= (unsigned char *) buf;

    for(int i=0; i<total_blocks; i++){
        if(free_blocks[i]==1){
            Console::puts("Returning the free bolck: ");
            Console::puti(i);  Console::puts("\n ");
            return i;
        }
    }
    return -1;
}
